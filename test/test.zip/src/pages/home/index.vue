<template>
    <div id="home">
        首页
    </div>
</template>
<script>
  export default{
    data () {
      return {}
    },
    components: {},
    methods: {},
    mounted () {

    },
    watch: {}
  }

</script>
