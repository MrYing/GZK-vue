<template>
  <div id="app">
    <div id="main_box" >
      <router-view></router-view>

      <!-- <keep-alive exclude="enroll">
         <router-view v-if="$route.meta.keepAlive"></router-view>
       </keep-alive>
       <router-view v-if="!$route.meta.keepAlive"></router-view>-->
    </div>
  </div>
</template>

<script>


export default {
  name: 'app',
  data() {
    return{
    }
  },
  components: {

  },
  computed: {

  },
}
</script>

<style>


</style>
