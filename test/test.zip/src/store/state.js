export default {
    user: {
        nickName : '这是一只二哈',
        isLogin : false
    }
}
